How to use GitHub Actions to build the LSPosed AOD Fix APK
==========================================================

1. Create a new repository on GitHub (e.g. AOD-Fix-LSPosed).
2. Upload the entire AodFixModule folder (this project) to that repo.
3. Make sure the .github/workflows/build.yml file is included (this is the CI config).
4. Commit and push to the "main" branch.
5. Go to your repo -> Actions tab -> wait for the workflow to complete.
6. Download the built APK from the "AOD-Fix-APK" artifact.

After downloading:
- Install APK on your phone.
- Open LSPosed Manager, enable module for "com.transsion.aod".
- Reboot, test AOD.

Notes:
- First run might take a few minutes to build.
- You need to push with either the GitHub app or mobile web upload.
